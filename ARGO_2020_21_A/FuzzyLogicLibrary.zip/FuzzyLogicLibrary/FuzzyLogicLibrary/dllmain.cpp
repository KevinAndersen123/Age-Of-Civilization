#include <stdio.h>
#include <Windows.h>
#include <time.h>

BOOL APIENTRY DllMain(HMODULE hModule, DWORD ul_reason_for_call, LPVOID lpReserved)
{
    switch (ul_reason_for_call)
    {
    case DLL_PROCESS_ATTACH:
        break;
    case DLL_THREAD_ATTACH:
        break;
    case DLL_THREAD_DETACH:
        break;
    case DLL_PROCESS_DETACH:
        break;
    }
    return TRUE;
}

extern "C" _declspec(dllexport) float FuzzyTriangleLB(float t_value, float t_x0, float t_x1, float t_x2)
{
	float result = 0;
	float x = t_value;

	if ((x <= t_x0) || (x >= t_x2))
	{
		result = 0;
	}
	else if (x == t_x1)
	{
		result = 1.0f;
	}
	else if ((x > t_x0) && (x < t_x1))
	{
		result = ((x - t_x0) / (t_x1 - t_x0));
	}
	else
	{
		result = ((t_x2 - x) / (t_x2 - t_x1));
	}

	return result;
}

extern "C" _declspec(dllexport) float FuzzyGradeUpLB(float t_value, float t_x0, float t_x1)
{
	float result = 0;
	float x = t_value;

	if (x <= t_x0)
	{
		result = 0;
	}
	else if (x > t_x1)
	{
		result = 1.0f;
	}
	else
	{
		result = ((x - t_x0) / (t_x1 - t_x0));
	}

	return result;
}

extern "C" _declspec(dllexport) float FuzzyGradeDownLB(float t_value, float t_x0, float t_x1)
{
	float result = 0;
	float x = t_value;

	if (x <= t_x0)
	{
		result = 1.0f;
	}
	else if (x > t_x1)
	{
		result = 0;
	}
	else
	{
		result = ((x - t_x0) / (t_x1 - t_x0));
	}

	return result;
}

extern "C" _declspec(dllexport) float FuzzyTrapezoidLB(float t_value, float t_x0, float t_x1, float t_x2, float t_x3)
{
	float result = 0;
	float x = t_value;

	if ((x <= t_x0) || (x >= t_x3))
	{
		result = 0;
	}
	else if ((x >= t_x1) && (x <= t_x2))
	{
		result = 1.0f;
	}
	else if ((x > t_x0) && (x < t_x1))
	{
		result = ((x - t_x0) / (t_x1 - t_x0));
	}
	else
	{
		result = ((t_x3 - x) / (t_x3 - t_x2));
	}

	return result;
}

extern "C" _declspec(dllexport) float FuzzyANDLB(float t_value1, float t_value2)
{
	return min(t_value1, t_value2);
}

extern "C" _declspec(dllexport) float FuzzyORLB(float t_value1, float t_value2)
{
	return max(t_value1, t_value2);
}

extern "C" _declspec(dllexport) float FuzzyNOTLB(float t_value1)
{
	return 1.0f - t_value1;
}