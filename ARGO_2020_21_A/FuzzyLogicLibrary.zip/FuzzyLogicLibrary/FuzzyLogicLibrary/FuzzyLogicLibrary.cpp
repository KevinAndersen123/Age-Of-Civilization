#include <iostream>

int main()
{
    std::cout << "I have been built!\n";
    return 0;
}
