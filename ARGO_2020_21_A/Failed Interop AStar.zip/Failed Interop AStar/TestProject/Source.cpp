#include "Map.h"

int main()
{
	Map map("", "LevelMap.json");

	system("PAUSE");
	return 0;
}