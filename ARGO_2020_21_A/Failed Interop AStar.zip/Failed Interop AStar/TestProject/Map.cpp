#include "Map.h"

Map::Map(std::string t_filePath, std::string t_fileName)
{
	loadMap(t_filePath + t_fileName);
	std::vector<std::pair<int, int>> path = getPath(std::pair<int,int>(50, 8), std::pair<int, int>(49, 16));

	json pathFile;

	pathFile.push_back(path);

	std::ofstream writer;
	writer.open("Path.json");
	writer << pathFile.dump(4);
}

Map::~Map()
{
}

int Map::multiply(int t_int)
{
	return t_int * 10;
}

void Map::loadMap(std::string t_fileName)
{
	std::ifstream reader(t_fileName);

	json jsonFile;

	reader >> jsonFile;

	reader.close();

	m_width = jsonFile["m_width"];
	m_height = jsonFile["m_height"];

	for (int x = 0; x < m_width; x++)
	{
		std::vector<Tile*> col;

		for (int y = 0; y < m_height; y++)
		{
			Tile* tile = new Tile();

			tile->m_indexPos = std::pair<int, int>(x, y);
			col.push_back(tile);
		}

		m_grid.push_back(col);
	}

	for (auto& col : jsonFile["m_colData"].items()) 
	{
		for (auto& row : col.value().items())
		{
			for (auto& cell : row.value().items())
			{
				int x = std::stoi(col.key());
				int y = std::stoi(cell.key());

				m_grid[x][y]->m_type = static_cast<TileType>(cell.value()["m_tileType"]);
				m_grid[x][y]->m_position.first = static_cast<float>(cell.value()["m_xPos"]);
				m_grid[x][y]->m_position.second = static_cast<float>(cell.value()["m_yPos"]);
			}		
		}
	}

	setupNeighbours();
}

void Map::setupNeighbours()
{
	for (int x = 0; x < m_width; x++)
	{
		for (int y = 0; y < m_height; y++)
		{
			std::vector<std::pair<int, int>> neighbourOffsets;

			neighbourOffsets.push_back(std::pair<int, int>(-1, 0));
			neighbourOffsets.push_back(std::pair<int, int>(1, 0));

			if (y % 2 != 0)
			{
				neighbourOffsets.push_back(std::pair<int, int>(0, 1));
				neighbourOffsets.push_back(std::pair<int, int>(1, 1));
				neighbourOffsets.push_back(std::pair<int, int>(0, -1));
				neighbourOffsets.push_back(std::pair<int, int>(1, -1));
			}
			else
			{
				neighbourOffsets.push_back(std::pair<int, int>(-1, 1));
				neighbourOffsets.push_back(std::pair<int, int>(0, 1));
				neighbourOffsets.push_back(std::pair<int, int>(-1, -1));
				neighbourOffsets.push_back(std::pair<int, int>(0, -1));
			}

			for (std::pair<int, int> offset : neighbourOffsets)
			{
				int xPos = x + offset.first;
				int yPos = y + offset.second;

				if (xPos >= 0 && xPos < m_width && yPos >= 0 && yPos < m_height)
				{
					m_grid[x][y]->m_neighbours.push_back(m_grid[xPos][yPos]);
				}
			}
		}
	}
}

std::vector<std::pair<int, int>> Map::getPath(std::pair<int, int> t_startTile, std::pair<int, int> t_endTile)
{
	Tile* startTile = m_grid[t_startTile.first][t_startTile.second];
	Tile* endTile = m_grid[t_endTile.first][t_endTile.second];

	std::vector<std::pair<int, int>> path = {};

	std::priority_queue<Tile*, std::vector<Tile*>, TileCompare> pq;

	if (endTile->m_type == TileType::Mountain || endTile->m_type == TileType::Water)
	{
		return path;
	}

	for (int col = 0; col < m_width; col++)
	{
		for (int row = 0; row < m_height; row++)
		{
			m_grid[col][row]->m_isMarked = false;
			m_grid[col][row]->m_previous = nullptr;
			m_grid[col][row]->m_pathCost = std::numeric_limits<int>::max();
			m_grid[col][row]->m_heuristicCost = CalculateDistance(m_grid[col][row]->m_position, endTile->m_position);
		}
	}

	startTile->m_pathCost = 0;
	pq.push(startTile);
	startTile->m_isMarked = true;

	while (!pq.empty() && pq.top() != endTile)
	{
		for(Tile* tile : pq.top()->m_neighbours)
		{
			if (tile != pq.top()->m_previous)
			{
				if (tile-> m_type != TileType::Mountain && tile->m_type != TileType::Water)
				{
					float childCost = tile->m_WEIGHT_COST + pq.top()->m_pathCost;

					if (childCost < tile->m_pathCost)
					{
						tile->m_pathCost = childCost;
						tile->m_previous = pq.top();
					}

					if (tile->m_isMarked == false)
					{
						pq.push(tile);
						tile->m_isMarked = true;
					}
				}
			}
		}

		pq.pop();
	}

	if (endTile->m_previous != nullptr)
	{
		Tile* pathTile = endTile;

		while (pathTile != startTile && pathTile != nullptr)
		{
			path.push_back(pathTile->m_indexPos);
			pathTile = pathTile->m_previous;
		}
	}

	return path;
}

float Map::CalculateDistance(std::pair<float, float> t_pos1, std::pair<float, float> t_pos2)
{
	return sqrt(powf(t_pos2.first - t_pos1.first, 2) + powf(t_pos2.second - t_pos1.second, 2));
}
