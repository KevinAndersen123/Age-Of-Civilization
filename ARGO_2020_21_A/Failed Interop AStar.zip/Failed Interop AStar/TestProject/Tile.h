#pragma once
#include <iostream>
#include <vector>

enum class TileType
{
	Mountain,
	Land,
	Sand,
	Water
};

class Tile
{
public:

	const float m_WEIGHT_COST = 2.61f;

	Tile();
	~Tile();

	std::pair<int, int> m_indexPos;
	std::pair<float, float> m_position;
	
	Tile* m_previous;

	std::vector<Tile*> m_neighbours;

	TileType m_type;

	float m_pathCost = 0.0f;
	float m_heuristicCost = 0.0f;

	bool m_isMarked = false;
};

class TileCompare
{	
public:

	bool operator()(Tile* t_tile1, Tile* tile2);
};