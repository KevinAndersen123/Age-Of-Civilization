#include "Tile.h"

Tile::Tile()
{
	m_indexPos = std::pair<int,int>(-1, -1);
	m_position = std::pair<float, float>(-1.0f, -1.0f);
	m_previous = nullptr;
}

Tile::~Tile()
{
	m_previous = nullptr;
	m_neighbours.clear();
}

bool TileCompare::operator()(Tile* t_tile1, Tile* tile2)
{
	return t_tile1->m_pathCost + t_tile1->m_heuristicCost > tile2->m_pathCost + tile2->m_heuristicCost;
}