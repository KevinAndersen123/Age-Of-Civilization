#pragma once
#include "Tile.h"
#include "json.hpp"
#include <fstream>
#include <queue>
#include <limits>

using json = nlohmann::json;

class Map
{
public:

	Map(std::string t_filePath, std::string t_fileName);
	~Map();

	int multiply(int t_int);

private:

	int m_width;
	int m_height;

	std::vector<std::vector<Tile*>> m_grid = {};

	void loadMap(std::string t_fileName);
	void setupNeighbours();

	std::vector<std::pair<int, int>> getPath(std::pair<int, int> t_startTile, std::pair<int, int> t_endTile);

	static float CalculateDistance(std::pair<float, float> t_pos1, std::pair<float, float> t_pos2);
};

